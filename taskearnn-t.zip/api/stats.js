export default async function handler(req, res) {
  // Fake stats endpoint (no persistence). Returns zeros and now timestamp.
  if (req.method !== 'GET') return res.status(405).json({ ok:false, error:'Method Not Allowed' });
  const { userId } = req.query;
  return res.status(200).json({
    ok: true,
    userId: userId || null,
    totals: { referrals: 0, referralPoints: 0, points: 0 },
    serverTime: new Date().toISOString()
  });
}
