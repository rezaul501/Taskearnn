export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false, error: 'Method Not Allowed' });
  try {
    const { userId, action, points } = req.body || {};
    if (!userId || typeof action !== 'string' || typeof points !== 'number') {
      return res.status(400).json({ ok:false, error:'Missing userId/action/points' });
    }
    // Normally you'd store this event in a DB. Demo only:
    return res.status(200).json({ ok:true, userId, action, points, loggedAt: new Date().toISOString() });
  } catch (e) {
    return res.status(500).json({ ok:false, error: e.message || 'Unknown error' });
  }
}
