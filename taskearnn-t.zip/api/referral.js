export default async function handler(req, res) {
  // Demo API: logs referrals. No persistent storage.
  if (req.method !== 'POST') return res.status(405).json({ ok: false, error: 'Method Not Allowed' });
  try {
    const { referrerId, referredId } = req.body || {};
    if (!referrerId || !referredId) return res.status(400).json({ ok:false, error:'Missing referrerId or referredId' });
    if (referrerId === referredId) return res.status(400).json({ ok:false, error:'Self-referral blocked' });

    // Here you would normally write to a database (Vercel KV / Supabase / etc.)
    // This demo just echoes back.
    return res.status(200).json({ ok:true, referrerId, referredId, notedAt: new Date().toISOString() });
  } catch (e) {
    return res.status(500).json({ ok:false, error: e.message || 'Unknown error' });
  }
}
