
# TaskEarnn (Vercel Ready)

A minimal Telegram-style mini-app you can deploy to Vercel. Frontend stores points locally; simple API routes are included for future integration (no database by default).

## Folder Structure
```
/api
  ├─ referral.js   # POST { referrerId, referredId } -> 200 (demo)
  ├─ task.js       # POST { userId, action, points } -> 200 (demo)
  └─ stats.js      # GET  ?userId=... -> demo totals
index.html
vercel.json
```

> ⚠️ The demo API has **no persistence**. To make referrals/points permanent, connect a real DB:
- Vercel KV (Redis)  
- Supabase / Neon (Postgres)  
- Firebase / Firestore

Replace the `// Normally you'd store...` blocks with DB calls.

## Deploy on Vercel
1. Download this ZIP and extract.
2. Create a new Vercel project, **import from your local folder** or push to Git and import.
3. No build step needed (pure static + serverless functions). Just deploy.
4. Open the deployed URL. Your referral link (non-bot) will look like:
   ```
   https://<your-domain>/?ref=<your-user-id>
   ```
   If you use a Telegram bot, update the referral link code in `index.html` to your bot deeplink.

## Telegram Tips
- Ensure your domain is allowed in your bot's `Web App` settings.
- We set `X-Frame-Options: ALLOWALL` so the app can render in Telegram's in-app webview.
- If you keep the ad network, make sure it is permitted in your region and meets Telegram's policies.
